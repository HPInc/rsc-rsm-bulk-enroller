# Copyright 2024 HP Development Company, L.P.
# SPDX-License-Identifier: MIT
'''RSC bulk enrollment tool'''
import logging
logging.basicConfig(level=logging.WARN,
                        format='%(asctime)s - %(levelname)s - %(message)s')
